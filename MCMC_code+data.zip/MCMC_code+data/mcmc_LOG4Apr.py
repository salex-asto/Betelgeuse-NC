import numpy as np
import matplotlib.pyplot as plt
import corner
import emcee
from scipy.interpolate import interp1d
from multiprocessing import Pool
print(emcee.__version__)


def flux_function(logg, norm):
    flux = flux_36 + (logg+0.2)/(0.4-(-0.2))*(flux_37-flux_36)
    flux = flux/norm
    return flux


def rpars(init_dist):
    return [np.random.rand()*(i[1]-i[0])+i[0] for i in init_dist]


def lnprior(priors, values):
    lp = 0
    for value, prior in zip(values, priors):
        if value >= prior[0] and value <= prior[1]:
            lp += 0
        else:
            lp += np.inf
    return lp


def lnprob(z):
    lnp = lnprior(priors, z)
    if not np.isfinite(lnp):
        return -np.inf

    # make a model using the values the sampler generated
    model = flux_function(z[0], z[1])

    # use chi^2 to compare the model to the data:
    chi2 = np.sum((Y-model)**2)/(sigma**2)

    # calculate lnp
    lnprob = -0.5 * chi2 + lnp
    return lnprob


if __name__ == '__main__':
    # the observation data
    X, Y = np.loadtxt('data/4Apr_8660.obs', unpack=True)
    X = X[7:]
    Y = Y[7:]

    # the model at 3600K, interpolate at observation spectra length.
    xt36, yt36 = np.loadtxt('data/8660_3600g-0.2_CNO_R65000.bmg', unpack=True)
    interp1d_36 = interp1d(xt36, yt36)
    flux_36 = interp1d_36(X)

    # the model at 3700k, interpolate at observation spectra length.
    xt37, yt37 = np.loadtxt('data/8660_3600g+0.4_CNO_R65000.bmg', unpack=True)
    interp1d_37 = interp1d(xt37, yt37)
    flux_37 = interp1d_37(X)

    # with Pool() as pool:

    ndim = 2
    nwalkers = 50000
    nburn = 1000
    nsteps = 200

    priors = [(-0.2, 0.4), (0.95, 1.15)]
    init_dist = [(-0.2, 0.4), (0.95, 1.15)]
    sigma = 0.03

    p0 = np.array([rpars(init_dist) for i in range(nwalkers)])
    sampler = emcee.EnsembleSampler(nwalkers, ndim, lnprob)
    sampler.run_mcmc(p0, nsteps)
    print("done")

    # emcee_trace = sampler.chain[:, nburn:, :].reshape(-1, ndim).T
    samples = sampler.chain[:, 50:, :].reshape((-1, ndim))
    fig = corner.corner(samples, labels=["log $g$", "Norm"], show_titles=True, title_fmt='.3f',
                        quantiles=[0.16, 0.5, 0.84], title_kwargs={"fontsize": 12})
    fig.suptitle('04-04-2020', x=0.75, y=0.7,color='black',fontsize=12)
    plt.savefig('corner_logg_4Apr.eps', dpi=200)
    fig = plt.figure()
    temp = np.quantile(samples[50:, 0], 0.5)
    norm = np.quantile(samples[50:, 1], 0.5)
    plt.plot(X, Y, label='Data')
    plt.plot(X, flux_function(temp, norm), label='Model')
    plt.plot(X, Y-flux_function(temp, norm), label='Residual')
    plt.xlabel('Wavelength ($\mathrm{\AA}$)')
    plt.ylabel('Normalized Flux')
    plt.title("log$g$ = 0.0")
    plt.legend()
    plt.savefig('logg_4Apr.eps', dpi=200)


